// Script kosong untuk pengembangan interaksi di masa depan
